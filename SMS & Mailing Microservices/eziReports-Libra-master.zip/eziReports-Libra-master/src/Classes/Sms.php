<?php
    namespace Libra\Classes;

    use Libra\Classes\App;

    class Sms extends App
    {
        public function sms($data)
        {
            
        }

        public function send($data)
        {
            
        }
    }
    